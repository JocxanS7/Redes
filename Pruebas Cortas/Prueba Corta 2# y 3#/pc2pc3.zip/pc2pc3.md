IC: 7602-Redes - Semestre 2.

Jocxan Sandi Batista.


---

# Prueba Corta 2 y 3

Para ejecutar el codigo **gcc pc2pc3.c -o quiz -lm** ya que ocupa la librería de math
Y luego  ./quiz

Implementar una pequeña aplicación que realice los cálculos de Hamming(7,4) en lenguaje
de programación C. 

**EStado de la prueba corta:**  No realizada. 

**Motivo** Haciendo pruebas, tenía problemas con los corrimientos a la izquierda pero hasta el final me di cuenta del error por lo que no tuve más tiempo para realizar la tarea.

## Referencias 
> Tutorialspoint: https://www.tutorialspoint.com/conversion-of-hex-decimal-to-integer-value-using-c-language

> Programiz https://www.programiz.com/c-programming/bitwise-operators